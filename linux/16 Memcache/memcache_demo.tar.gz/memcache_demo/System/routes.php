<?php 

Route::get('/','Home/Index/index');