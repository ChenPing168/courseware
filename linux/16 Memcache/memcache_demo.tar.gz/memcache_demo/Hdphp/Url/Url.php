<?php namespace Hdphp\Url;

//URL处理类
class Url
{
	private $app;

	public function __construct($app)
	{
		$this->app = $app;
	}

}