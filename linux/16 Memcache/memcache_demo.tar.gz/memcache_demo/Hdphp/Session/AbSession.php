<?php namespace Hdphp\Session;

interface AbSession
{
	public function make();
}