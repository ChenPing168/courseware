<?php namespace Hdphp\Facade;

use Hdphp\Kernel\Facade;

class ValidateFacade extends Facade
{
	public static function getFacadeAccessor()
	{
		return 'Validate';
	}
}