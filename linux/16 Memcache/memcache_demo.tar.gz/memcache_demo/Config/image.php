<?php
return array(
    #水印
    'font'              => 'hdphp/Image/font.ttf',  //水印字体
    'image'             => 'hdphp/Image/water.png', //水印图像
    'pos'               => 9,                       //位置  1~9九个位置  0为随机
    'pct'               => 60,                      //透明度
    'quality'           => 80,                      //压缩比
    'text'              => 'WWW.HOUDUNWANG.COM',    //水印文字
    'text_color'        => '#f00f00',               //文字颜色
    'text_size'         => 12,                      //文字大小
);