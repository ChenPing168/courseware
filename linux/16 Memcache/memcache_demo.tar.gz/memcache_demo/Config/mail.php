<?php
return array(
	'ssl'=>false,
	'username' => 'hdcms@houdunwang.com',
	'password' => 'admin521',
	'host' => 'smtp.exmail.qq.com',
	'port' => '25',
	'fromname' => '后盾网',
	'frommail' => 'hdcms@houdunwang.com',
	);