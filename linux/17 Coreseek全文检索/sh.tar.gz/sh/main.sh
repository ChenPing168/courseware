/usr/local/coreseek/bin/indexer main --rotate >> /usr/local/coreseek/var/log/main.log

