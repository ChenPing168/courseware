/usr/local/coreseek/bin/indexer delta --rotate >> /usr/local/coreseek/var/log/delta.log

